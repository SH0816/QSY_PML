#!/bin/bash

yhrun -pthcp1 -N 1 -n 1 ./main
