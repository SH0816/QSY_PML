
export PARMETIS_ROOT=/thfs1/home/test653/shutian/YHMAX/parmetis-4.0.3
export PARMETIS_BUILD_DIRS=${PARMETIS_ROOT}/build/Linux-aarch64
export LD_LIBRARY_PATH=/thfs1/home/test653/shutian/YHMAX/parmetis-4.0.3/build/_install/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/thfs1/home/test653/lc/lapack-3.10.0/build/lib:$LD_LIBRARY_PATH

